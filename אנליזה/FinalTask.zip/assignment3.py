"""
In this assignment you should find the area enclosed between the two given functions.
The rightmost and the leftmost x values for the integration are the rightmost and
the leftmost intersection points of the two functions.

The functions for the numeric answers are specified in MOODLE.


This assignment is more complicated than Assignment1 and Assignment2 because:
    1. You should work with float32 precision only (in all calculations) and minimize the floating point errors.
    2. You have the freedom to choose how to calculate the area between the two functions.
    3. The functions may intersect multiple times. Here is an example:
        https://www.wolframalpha.com/input/?i=area+between+the+curves+y%3D1-2x%5E2%2Bx%5E3+and+y%3Dx
    4. Some of the functions are hard to integrate accurately.
       You should explain why in one of the theoretical questions in MOODLE.

"""

import numpy as np
import time
import random
import matplotlib.pyplot as plt


class myFunction():
    def __init__(self, flag_list, minRange, maxRange, numberInRange):
        self.x = np.linspace(minRange, maxRange, numberInRange)
        self.function_list = []
        self.deriv_list = []
        self.flag_list = flag_list

        for flag in flag_list:
            self.function = np.zeros(len(self.x))
            self.deriv = np.zeros(len(self.x))
            for i, x in enumerate(self.x):
                (self.function[i], self.deriv[i]) = self.calcFunc(flag, x)
            self.function_list.append(self.function)
            self.deriv_list.append(self.deriv)

    def calcFunc(self, flag, x):
        if (flag == 1):  # -inf<x<inf
            function = 5
            deriv = 0
        elif (flag == 2):  # -inf<x<inf
            function = x ** 2 - 3 * x + 5
            deriv = 2 * x - 3
        elif (flag == 3):  # -inf<x<inf
            function = np.sin(x ** 2)
            deriv = 2 * x * np.cos(x ** 2)
        elif (flag == 4):  # -inf<x<inf
            function = np.exp(-2 * x ** 2)
            deriv = -4 * x * np.exp(-2 * x ** 2)
        elif (flag == 5):  # -inf<x<inf
            function = np.arctan(x)
            deriv = 1 / (x ** 2 + 1)
        elif (flag == 6):  # x!=0
            function = np.sin(x) / x
            deriv = (np.cos(x) * x - np.sin(x)) / x ** 2
        elif (flag == 7):  # x>0 & X!=1
            function = 1. / np.log(x)
            deriv = (-1 / x) / (np.log(x) ** 2)
        elif (flag == 8):
            function = np.exp(np.exp(x))
            deriv = np.exp(x) * function
        elif (flag == 9):  # x>=1
            function = np.log(np.log(x))
            deriv = 1 / np.log(x) * 1 / x
        elif (flag == 10):  # x>0
            function = np.sin(np.log(x))
            deriv = np.cos(np.log(x)) / x
        elif (flag == 11):  # x!=0
            function = 2 ** (1 / x ** 2) * np.sin(1 / x)
            deriv = (-2 ** (1 / x ** 2) / x ** 2) * (np.sin(1 / x) * 2 / x * np.log(2) + np.cos(1 / x))
        return function, deriv

    def getX(self):
        return self.x

    def getFunc(self, flag):
        index = self.flag_list.index(flag)
        return self.function_list[index]

    def Interpolate(self, fx, x_new):  # do not insert values in a out of function legal range
        def find_nearest(array, value):
            idx = np.abs(array - value).argmin()
            if (self.x[idx] > value):
                idx = idx - 1
            return idx, array[idx]

        fx_new = np.zeros(len(x_new))
        for i, x in enumerate(x_new):
            index, value = find_nearest(self.x, x)
            fx_new[i] = fx[index] + (x - self.x[index]) * \
                        (fx[index + 1] - fx[index]) / (self.x[index + 1] - self.x[index])

        return fx_new

    def plotFunction(self, ax, fx, x_vec, color='g', marker=None, linestyle='-'):
        ax.plot(x_vec, fx, color=color, marker=marker, linestyle=linestyle)
        ax.set_xlabel('x')
        ax.set_ylabel('f(x)')

    def intersection(self, ax, flag1, flag2, x0, eps=0.01):

        f1, d1 = self.calcFunc(flag1, x0)
        f2, d2 = self.calcFunc(flag2, x0)
        x_int = x0
        max_iter = 50
        while (abs(f2 - f1) > eps and max_iter > 0):
            ax.plot(x_int, f2, 'ok')
            x_int = x_int - (f2 - f1) / (d2 - d1)
            f1, d1 = self.calcFunc(flag1, x_int)
            f2, d2 = self.calcFunc(flag2, x_int)
            max_iter = max_iter - 1
        if (max_iter <= 0):
            print('max iter ')
            print(f'not found intersecrion point {x_int} diff fx {f2 - f1}')
        else:
            print(f'found intersecrion point x_int={x_int} diff fx {f2 - f1} f2 ={f2},f1={f1}')
        ax.plot(x_int, f2, 'om')

        return x_int

    def Integrate(self, f1, x):
        integral = 0
        for i, xx in enumerate(range(len(x) - 1)):
            integral += (f1[i] + f1[i + 1]) / 2 * (x[i + 1] - x[i])
        return integral

    def areabetween(self, f1, f2, x_vec):
        new_func = abs(f2 - f1)
        integral = self.Integrate(new_func, x_vec)
        return integral


class Assignment3:
    def __init__(self):
        """
        Here goes any one time calculation that need to be made before
        solving the assignment for specific functions.
        """

        pass

    def integrate(self, f: callable, a: float, b: float, n: int) -> np.float32:
        """
        Integrate the function f in the closed range [a,b] using at most n
        points. Your main objective is minimizing the integration error.
        Your secondary objective is minimizing the running time. The assignment
        will be tested on variety of different functions.

        Integration error will be measured compared to the actual value of the
        definite integral.

        Note: It is forbidden to call f more than n times.

        Parameters
        ----------
        f : callable. it is the given function
        a : float
            beginning of the integration range.
        b : float
            end of the integration range.
        n : int
            maximal number of points to use.

        Returns
        -------
        np.float32
            The definite integral of f between a and b
        """

        # replace this line with your solution
        flag1 = 1
        flag2 = 2
        minRange = 0
        maxRange = 3
        numberInRange = 80
        fig = plt.figure()
        ax = fig.add_subplot('111')
        func2 = myFunction([flag1, flag2], minRange, maxRange, numberInRange)
        x_new = np.linspace(minRange + 0.25, maxRange - 0.25, numberInRange_new)
        x_vec = func2.getX()
        # get f given flag
        f1 = func2.getFunc(flag1)
        func2.plotFunction(ax, f1, x_vec, color='r', marker=None)
        f2 = func2.getFunc(flag2)
        func2.plotFunction(ax, f2, x_vec, color='r', marker=None)
        integral = func2.Integrate(f1, x_vec)
        print(f'integral f1 ={integral}')
        integral_between = func2.areabetween(f1, f2, x_vec)
        print(f'integral_between f1,f2 ={integral_between}')
        plt.title('assignment 3')
        plt.grid()
        plt.show()

        result = np.float32(1.0)

        return result

    def areabetween(self, f1: callable, f2: callable) -> np.float32:
        """
        Finds the area enclosed between two functions. This method finds
        all intersection points between the two functions to work correctly.

        Example: https://www.wolframalpha.com/input/?i=area+between+the+curves+y%3D1-2x%5E2%2Bx%5E3+and+y%3Dx

        Note, there is no such thing as negative area.

        In order to find the enclosed area the given functions must intersect
        in at least two points. If the functions do not intersect or intersect
        in less than two points this function returns NaN.


        Parameters
        ----------
        f1,f2 : callable. These are the given functions

        Returns
        -------
        np.float32
            The area between function and the X axis

        """

        # replace this line with your solution
        result = np.float32(1.0)

        return result


##########################################################################


import unittest
from sampleFunctions import *
from tqdm import tqdm


class TestAssignment3(unittest.TestCase):

    def test_integrate_float32(self):
        ass3 = Assignment3()
        f1 = np.poly1d([-1, 0, 1])
        r = ass3.integrate(f1, -1, 1, 10)

        self.assertEquals(r.dtype, np.float32)

    def test_integrate_hard_case(self):
        ass3 = Assignment3()
        f1 = strong_oscilations()
        r = ass3.integrate(f1, 0.05, 10, 20)

        self.assertGreaterEqual(0.001, (r - 2.0998 * 10 ** 116) / 2.0998 * 10 ** 116)


if __name__ == "__main__":
    unittest.main()
