import networkx as nx
import math
import pandas as pd
from scipy.stats import binom_test as bt
import powerlaw as pl
import pickle

def get_name():
    return "Nizan Bar-El"


def get_id():
    return 322450552


def random_netwroks_generator(n, p, num_netwroks=1, directed=False, seed=get_id()):
    lstNet = []
    for i in range(0, num_netwroks):
        lstNet.append(nx.gnp_random_graph(n, p, seed, directed))
    return lstNet


def network_stats(nxObject):
    dicNet = {}
    # degrees_avg:
    if nxObject.is_directed():
        dicNet['degrees_avg'] = (len(nxObject.in_edges) + len(nxObject.out_edges)) / nxObject.number_of_nodes()
    else:
        dicNet['degrees_avg'] = (nxObject.number_of_edges() * 2) / nxObject.number_of_nodes()

    sum = 0
    min = math.inf
    max = -1
    for i in nx.degree(nxObject):
        sum += ((i[1] - dicNet['degrees_avg']) ** 2)
        if i[1] > max:
            max = i[1]
        if i[1] < min:
            min = i[1]
    dicNet['degrees_std'] = math.sqrt(sum)
    dicNet['degrees_min'] = min
    dicNet['degrees_max'] = max
    try:
        dicNet['spl'] = nx.average_shortest_path_length(nxObject)
    except:
        dicNet['spl'] = -1  # if the network is not conncted their is a problem coused becouse there is no shortest path betwwen some of the pairs so i will retuen -1 so we know it cant be done
    try:
        dicNet['diameter'] = nx.diameter(nxObject)
    except:
        dicNet['diameter'] = -1  # if the network is not conncted their is a problem coused becouse there is no shortest path betwwen some of the pairs so i will retuen -1 so we know it cant be done
    return dicNet


def networks_avg_stats(lstNet):
    dicNetAvrage = {}
    sumDegree = 0
    sumStd = 0
    sumMin = 0
    sumMax = 0
    sumSpl = 0
    sumDiameter = 0
    numOfNotConnectedNet = 0
    temp = {}
    for i in lstNet:
        temp = network_stats(i)
        sumDegree += temp['degrees_avg']
        sumStd += temp['degrees_std']
        sumMin += temp['degrees_min']
        sumMax += temp['degrees_max']
        if temp['spl'] == -1 or temp['diameter'] == -1:  # in case of not conncted network i will not count the netwrk as part of the avrage spl and diameter
            numOfNotConnectedNet += 1
        else:
            sumSpl += temp['spl']
            sumDiameter += temp['diameter']
    dicNetAvrage['degrees_avg'] = sumDegree / len(lstNet)
    dicNetAvrage['degrees_std'] = sumStd / len(lstNet)
    dicNetAvrage['degrees_min'] = sumMin / len(lstNet)
    dicNetAvrage['degrees_max'] = sumMax / len(lstNet)
    if (len(
            lstNet) - numOfNotConnectedNet) == 0:  # if all the networks are not conncted there is no avarge so it returns -1 insted
        dicNetAvrage['spl'] = -1
        dicNetAvrage['diameter'] = -1
    else:
        dicNetAvrage['spl'] = sumSpl / (len(
            lstNet) - numOfNotConnectedNet)  # if the network is not conncted i will not calculate it in the avrage spl at all
        dicNetAvrage['diameter'] = sumDiameter / (len(
            lstNet) - numOfNotConnectedNet)  # if the network is not conncted i will not calculate it in the avrage diameter at all
    return dicNetAvrage


lstRandNets = pd.read_pickle('C:/Users/USER/Downloads/rand_nets.p')


def rand_net_hypothesis_testing(network, theoretical_p, alpha=0.05):
    if network.is_directed():
        p_value = bt((len(network.in_edges) + len(network.out_edges)),
                     network.number_of_nodes() * (network.number_of_nodes() - 1), theoretical_p)
    else:
        p_value = bt(network.number_of_edges(), (network.number_of_nodes() * (network.number_of_nodes() - 1)) / 2,
                     theoretical_p)
    if p_value > alpha:
        return (p_value, 'accept')
    else:
        return (p_value, 'reject')


def most_probable_p(nxObjext):
    tempLst = [0.01, 0.1, 0.3, 0.6]
    p_value = 0
    bestP = -1
    for i in tempLst:
        tempT = rand_net_hypothesis_testing(nxObjext, i)
        if tempT[1] == 'accept':
            if tempT[0] > p_value:
                p_value = tempT[0]
                bestP = i
    if p_value == -1:
        return -1
    else:
        return bestP


lstScaleFree = pd.read_pickle('C:/Users/USER/Downloads/scalefree_nets.p')


def find_opt_gamma(network, treat_as_social_network=True):
    nodeDegreeLst = []
    for i in nx.degree(network):
        nodeDegreeLst.append(i[1])
    if treat_as_social_network:
        fit = pl.Fit(nodeDegreeLst, estimate_discrete=treat_as_social_network)
    else:
        fit = pl.Fit(nodeDegreeLst)
    return fit.power_law.alpha


#lst = pd.read_pickle('C:/Users/USER/Downloads/mixed_nets.p')
with open('mixed_nets.p','rb') as f:
  lst = pickle.load(f)

def netwrok_classifier(network):
    optGamma = find_opt_gamma(network)
    if optGamma > 2.0 and optGamma < 3.0:
        return 2
    else:
        return 1

