import networkx as nx
from networkx.algorithms.community import k_clique_communities
from networkx.algorithms.community import girvan_newman
import community
import json
import pandas as pd
from datetime import date, timedelta

def get_name():
    return "Nizan Bar-El"
def get_id():
    return 322450552

##get one qlique and calculate its mudolarity
def ModularityC(lst, net):
    L = nx.number_of_edges(net)
    Lc = 0
    E = list(net.edges())
    for i in lst:
        for j in lst:
            if (i, j) in E:
                Lc += 1
    Kc = 0
    for i in lst:
        Kc += net.degree[i]
    if len(lst) == 0:
        nodes = list(net.nodes)
        modularity = 0
        for i in nodes:
            modularity -= (net.degree[i] / (2 * L)) ** 2
        return modularity
    return ((Lc / L) - (Kc / (2 * L)) ** 2)


def community_detector(algorithm_name, network, most_valualble_edge=None):
    final = {}
    lst_communities = []
    if algorithm_name == "clique_percolation":
        max_modularity = 0
        best_partition = []
        for i in range(2, network.number_of_nodes()):
            try:
                partition = list(k_clique_communities(network, i))
                modularity_temp = 0
                if (partition != []):
                    for j in partition:
                        modularity_temp += ModularityC(list(j), network)
                if modularity_temp > max_modularity:
                    max_modularity = modularity_temp
                    best_partition = partition
            except:
                break
        if max_modularity == 0 and len(best_partition) == 0:
            max_modularity = ModularityC(best_partition, network)
        final["num_partitions"] = len(best_partition)
        final["modularity"] = max_modularity
        for i in best_partition:
            lst_communities.append(list(i))
        final["partition"] = lst_communities
    elif algorithm_name == "girvin_newman":
        partition_and_modularity_lst = []
        if most_valualble_edge != None:
            comp = girvan_newman(network, most_valualble_edge)
        else:
            comp = girvan_newman(network)
        it = 0
        while it is not None:
            it = next(comp,None)
            if it is not None:
                communities = list(set(sorted(c)) for c in it)
                temp_m = nx.algorithms.community.modularity(network,communities)
                partition_and_modularity_lst.append((communities,temp_m))
        partition_and_modularity_lst = sorted(partition_and_modularity_lst, key=lambda tup: tup[1], reverse=True)
        best_partition = partition_and_modularity_lst[0]
        final["num_partitions"] = len(best_partition[0])
        final["modularity"] = best_partition[1]
        for i in best_partition[0]:
            lst_communities.append(list(i))
        final["partition"] = lst_communities

    elif algorithm_name == "louvain":
        louvain_partition = community.best_partition(network)
        communities = set(louvain_partition.values())
        final["num_partitions"] = len(communities)
        final["modularity"] = community.modularity(louvain_partition, network)
        for i in range(0, len(communities)):
            temp_lst = []
            for j in louvain_partition:
                if louvain_partition[j] == i:  # need to do the same but to the ditionary
                    temp_lst.append(j)
            lst_communities.append(temp_lst)
        final["partition"] = lst_communities
    return final


def edge_selector_optimizer(net):
    try:
        betweenness = nx.edge_betweenness_centrality(net, weight="weight")
        return max(betweenness, key=betweenness.get)
    except:
        betweenness = nx.edge_betweenness_centrality(net)
        return max(betweenness, key=betweenness.get)


def construct_heb_edges(files_path, start_date="2019-03-15", end_date="2019-04-15", non_parliamentarians_nodes=0):
    edge_dict = {}  # the dict that will save the edges
    tweets = []
    #we difine the the dates we can take the txt files
    s_year = int(start_date[0:4])
    e_year = int(end_date[0:4])
    s_month = int(start_date[5:7])
    e_month = int(end_date[5:7])
    s_day = int(start_date[8:10])
    e_day = int(end_date[8:10])
    current_path = ""
    start_date = date(s_year, s_month, s_day)
    end_date = date(e_year, e_month, e_day)
    delta = timedelta(days=1)
    while start_date <= end_date:
        current_path = files_path +"/Hebrew_tweets.json." + start_date.strftime("%Y-%m-%d") + ".txt"
        for t in open(current_path, 'r'):  # openning the tweets al loading them
            tweets.append(json.loads(t))
        start_date += delta



    for t in range(0,len(tweets)):  # adding to the dict the edges by getting the retweeted counter on the id of the users
        not_retweet = False
        try:
            temp_tupel = (tweets[t]['user']['id'], tweets[t]['retweeted_status']['user']['id'])
        except:
            not_retweet = True
        if not not_retweet:
            if temp_tupel not in edge_dict:
                edge_dict[temp_tupel] = 1  # the first edge
            else:
                edge_dict[temp_tupel] = edge_dict[temp_tupel] + 1  # adding whight to the edge whight


    # remove any one that is not the central political players
    colnames = ['p_id', 'name']
    central_political_players = pd.read_csv(files_path + "/central_political_players.csv", names=colnames)
    central_political_players_id_lst = central_political_players.p_id.tolist()
    temp = [] #this will help us to make the politcian id list to int
    for i in range(1,len(central_political_players_id_lst)):
        temp.append(int(central_political_players_id_lst[i]))
    central_political_players_id_lst = temp
    if non_parliamentarians_nodes != 0:  # remove any one that is not a central political players
        #lets find the most central users by checking thier wieght of in degree

        centarl_users = []
        central_users_in = []  # this will save th id of the ones we added
        for i in edge_dict:
            temp_wieght = 0
            if i[1] not in central_users_in:
                for j in edge_dict:
                    if i[1] == j[1] and i[1] not in central_political_players_id_lst:
                        temp_wieght += edge_dict[j]
                if i[1] not in central_political_players_id_lst:
                    centarl_users.append((i[1], temp_wieght))
                    central_users_in.append(i[1])
            # after we added to a list all of the user and thier in degree weight i can sorst in to find which are the most central users so i wont deletd their retweets
        centarl_users = sorted(centarl_users, key=lambda tup: tup[1], reverse=True)
        for i in range(0, non_parliamentarians_nodes):
            central_political_players_id_lst.append(centarl_users[i][0])
    nodes_to_remove = []
    for i in edge_dict:
        if not (i[0] in central_political_players_id_lst and i[1] in central_political_players_id_lst):
            nodes_to_remove.append(i)
    for i in nodes_to_remove:
        del edge_dict[i]

    return edge_dict

def construct_heb_network(edge_dictionary):
    Graph = nx.Graph()
    edges_lst = []
    for i in edge_dictionary:
        edges_lst.append((i[0], i[1], edge_dictionary[i]))
    Graph.add_weighted_edges_from(edges_lst)
    return Graph

